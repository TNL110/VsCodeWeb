import React, { Component } from "react";

export default class Dashboard extends Component {
  render() {
    return (
      <div>
        <h4>Dashboard</h4>
      </div>
    );
  }
}
